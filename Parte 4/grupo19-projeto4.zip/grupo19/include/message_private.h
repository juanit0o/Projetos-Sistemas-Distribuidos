//GRUPO 19
//Diogo Pinto - 52763
//Francisco Ramalho - 53472
//João Funenga - 53504

#include "sdmessage.pb-c.h"

struct message_t{
  MessageT *message;
};
